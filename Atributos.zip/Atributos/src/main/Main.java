/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

//import pessoa.Pessoa;

import aluno.Aluno;


/**
 *
 * @author LABORATORIO 01
 */
public class Main {
    public static void main(String[] args) {
        
        
        Aluno a1 = new Aluno ();
         Aluno a2 = new Aluno ();
         
        
        
        a1.nome = "joão";
        a2.nome = "Maria";
        

      a1.curso = "ADS";
      a2.curso ="Enfermagem";
      
      
      
        System.out.println(a1.nome);
        System.out.println(a2.nome);
        System.out.println(a1.curso);
        System.out.println(a2.curso);
       
       // Pessoa p1 = new Pessoa();
         //Pessoa p2 = new Pessoa();
         
       //p1.nome = "João";
       //p2.nome = "José";
       
       
     // p1.nacionalidade = "Brasileira";
       //p2.nacionalidade = "Americana";
               
       // System.out.println(p1.nome);
       // System.out.println(p2.nome);
       
       // System.out.println(p1.nacionalidade);
        //System.out.println(p2.nacionalidade);
       //p1.andar();
        
        
        
    }
    
}
